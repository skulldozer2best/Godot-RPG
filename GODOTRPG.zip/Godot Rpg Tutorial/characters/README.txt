Player and skeleton sprites are on a 48x48 grid.
Slime is on a 32x32 grid.

Flip right facing sprites to get the left facing sprites.

Animations [rows (0 based for us programmers)]
Player:
[0 - 2] idle
[3 - 5] move
[6 - 8] attack
[9] death

Enemies:
[0 - 2] idle
[3 - 5] move
[6 - 8] attack
[9 - 11] damaged
[12] death